import { expect, test } from '@playwright/test';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import JSZip from '../docs/node_modules/jszip/lib/index.js';
test('keeps native exact row height with explicit cell padding while editing and reopening twice', async ({ page, context }) => {
  const audit = path.resolve('docs/audits/2026-11-26/word-cell-properties');
  await mkdir(audit, { recursive: true });
  const zip = await JSZip.loadAsync(await readFile('docs/audits/2026-11-26/word-math-groups/math-source.docx'));
  const xml = await zip.file('word/document.xml')!.async('string');
  const table = '<w:tbl><w:tblGrid><w:gridCol w:w="6000"/></w:tblGrid><w:tr><w:trPr><w:trHeight w:val="480" w:hRule="exact"/></w:trPr><w:tc><w:tcPr><w:vAlign w:val="bottom"/><w:tcMar><w:top w:w="0" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:t>Cell content</w:t></w:r></w:p></w:tc></w:tr></w:tbl>';
  zip.file('word/document.xml', xml.replace(/<w:body>[\s\S]*?(<w:sectPr[\s\S]*?<\/w:sectPr>)<\/w:body>/, `<w:body>${table}$1</w:body>`));
  const source = await zip.generateAsync({ type: 'nodebuffer' });
  await writeFile(path.join(audit, 'cell-source.docx'), source);
  await page.goto('/#/components/office-studio');
  const importFile = (buffer: Buffer, name: string) => page.getByLabel('导入文档文件', { exact: true }).setInputFiles({ name, mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', buffer });
  await importFile(source, 'Cell.docx');
  const body = page.getByRole('textbox', { name: 'Word 文档正文', exact: true });
  const cell = body.locator('td').first();
  const check = async () => {
    await expect(cell).toBeVisible();
    const metrics = await cell.evaluate(element => {
      const wrapper = element.querySelector<HTMLElement>('[data-word-cell-content]')!;
      return { height: element.getBoundingClientRect().height, top: getComputedStyle(wrapper).paddingTop, bottom: getComputedStyle(wrapper).paddingBottom };
    });
    expect(metrics.height).toBeGreaterThanOrEqual(31); expect(metrics.height).toBeLessThanOrEqual(33);
    expect(metrics.top).toBe('0px'); expect(parseFloat(metrics.bottom)).toBeCloseTo(20 / 3, 1);
  };
  await check();
  await cell.locator('p').click();
  await page.getByRole('tab', { name: '插入', exact: true }).click();
  await page.getByRole('button', { name: '单元格对齐与边距', exact: true }).click();
  await page.getByRole('button', { name: '下右对齐', exact: true }).click();
  await page.getByRole('textbox', { name: '单元格left内边距', exact: true }).fill('5.25');
  await page.getByRole('button', { name: '应用单元格属性', exact: true }).click();
  await check();
  for (let round = 1; round <= 2; round++) {
    const pending = page.waitForEvent('download');
    await page.getByRole('button', { name: '导出文件', exact: true }).click();
    const bytes = await readFile((await (await pending).path())!);
    await writeFile(path.join(audit, `cell-round-${round}.docx`), bytes);
    await importFile(bytes, `Cell-round-${round}.docx`);
    await check();
    await expect(cell).toHaveCSS('padding-left', '7px');
  }
  await page.evaluate(() => window.addEventListener('message', event => {
    if (event.data?.type === 'cell-print') (window as Window & { cellPrint?: string }).cellPrint = event.data.html;
  }));
  await page.addInitScript(() => { window.print = () => {
    window.parent.postMessage({ type: 'cell-print', html: document.documentElement.outerHTML }, '*');
    window.dispatchEvent(new Event('afterprint'));
  }; });
  await page.getByRole('button', { name: '打印', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as Window & { cellPrint?: string }).cellPrint)).toBeTruthy();
  const html = await page.evaluate(() => (window as Window & { cellPrint?: string }).cellPrint!);
  const preview = await context.newPage();
  await preview.setContent(html); await preview.evaluate(() => document.fonts.ready);
  const printed = await preview.locator('td').first().evaluate(element => {
    const wrapper = element.querySelector<HTMLElement>('[data-word-cell-content]')!;
    return { height: element.getBoundingClientRect().height, top: getComputedStyle(wrapper).paddingTop, bottom: getComputedStyle(wrapper).paddingBottom };
  });
  expect(printed.height).toBeGreaterThanOrEqual(31); expect(printed.height).toBeLessThanOrEqual(33);
  expect(printed.top).toBe('0px'); expect(parseFloat(printed.bottom)).toBeCloseTo(20 / 3, 1);
  await preview.pdf({ path: path.join(audit, 'cell-fixed-print.pdf'), preferCSSPageSize: true, printBackground: true });
  await writeFile(path.join(audit, 'cell-fixed-print-metrics.json'), JSON.stringify(printed, null, 2) + '\n');
  await preview.close();
  await page.screenshot({ path: path.join(audit, 'cell-fixed-light.png'), fullPage: true });
  await page.getByRole('button', { name: '切换暗色', exact: true }).click();
  await page.screenshot({ path: path.join(audit, 'cell-fixed-dark.png'), fullPage: true });
  await page.setViewportSize({ width: 320, height: 720 });
  await page.screenshot({ path: path.join(audit, 'cell-fixed-320.png'), fullPage: true });

});

test('moves actual text through all nine fixed-cell alignments and restores the transaction', async ({ page }) => {
  const audit = path.resolve('docs/audits/2026-11-26/word-cell-properties');
  const zip = await JSZip.loadAsync(await readFile(path.join(audit, 'cell-source.docx')));
  zip.file('word/document.xml', (await zip.file('word/document.xml')!.async('string')).replace('w:val="480" w:hRule="exact"', 'w:val="1440" w:hRule="exact"'));
  await page.goto('/#/components/office-studio');
  await page.getByLabel('导入文档文件', { exact: true }).setInputFiles({ name: 'Alignment.docx', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', buffer: await zip.generateAsync({ type: 'nodebuffer' }) });
  const cell = page.getByRole('textbox', { name: 'Word 文档正文', exact: true }).locator('td').first();
  await expect(cell).toBeVisible();
  const metrics = () => cell.evaluate(element => {
    const wrapper = element.querySelector<HTMLElement>('[data-word-cell-content]')!;
    const paragraph = wrapper.querySelector('p')!;
    const text = paragraph.firstChild!;
    const range = document.createRange(); range.selectNodeContents(text);
    const r = range.getBoundingClientRect(), w = wrapper.getBoundingClientRect();
    return { top: r.top - w.top, left: r.left - w.left, height: element.getBoundingClientRect().height, align: getComputedStyle(paragraph).textAlign };
  });
  const samples: Record<string, Awaited<ReturnType<typeof metrics>>> = {};
  for (const vertical of ['上', '中', '下']) {
    for (const horizontal of ['左', '中', '右']) {
      await cell.locator('p').click();
      await page.getByRole('tab', { name: '插入', exact: true }).click();
      await page.getByRole('button', { name: '单元格对齐与边距', exact: true }).click();
      await page.getByRole('button', { name: `${vertical}${horizontal}对齐`, exact: true }).click();
      await page.getByRole('button', { name: '应用单元格属性', exact: true }).click();
      const sample = await metrics(); samples[`${vertical}${horizontal}`] = sample;
      expect(sample.height).toBeGreaterThanOrEqual(95); expect(sample.height).toBeLessThanOrEqual(97);
      expect(sample.align).toBe(horizontal === '左' ? 'left' : horizontal === '中' ? 'center' : 'right');
    }
  }
  for (const horizontal of ['左', '中', '右']) {
    expect(samples[`中${horizontal}`].top - samples[`上${horizontal}`].top).toBeGreaterThan(20);
    expect(samples[`下${horizontal}`].top - samples[`中${horizontal}`].top).toBeGreaterThan(20);
  }
  for (const vertical of ['上', '中', '下']) {
    expect(samples[`${vertical}中`].left - samples[`${vertical}左`].left).toBeGreaterThan(50);
    expect(samples[`${vertical}右`].left - samples[`${vertical}中`].left).toBeGreaterThan(50);
  }
  await page.getByRole('tab', { name: '开始', exact: true }).click();
  await page.getByRole('button', { name: '撤销', exact: true }).click();
  expect((await metrics()).align).toBe('center');
  await page.getByRole('button', { name: '重做', exact: true }).click();
  expect((await metrics()).align).toBe('right');
  await writeFile(path.join(audit, 'cell-nine-alignments.json'), JSON.stringify(samples, null, 2) + '\n');
  await page.screenshot({ path: path.join(audit, 'cell-nine-alignments-light.png'), fullPage: true });
});
