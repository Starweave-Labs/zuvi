import { expect, test } from '@playwright/test';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import JSZip from '../docs/node_modules/jszip/lib/index.js';
test('keeps native exact row height with explicit cell padding while editing and reopening twice', async ({ page }) => {
  const audit = path.resolve('docs/audits/2026-11-26/word-cell-properties');
  await mkdir(audit, { recursive: true });
  const zip = await JSZip.loadAsync(await readFile('docs/audits/2026-11-26/word-math-groups/math-source.docx'));
  const xml = await zip.file('word/document.xml')!.async('string');
  const table = '<w:tbl><w:tblGrid><w:gridCol w:w="6000"/></w:tblGrid><w:tr><w:trPr><w:trHeight w:val="480" w:hRule="exact"/></w:trPr><w:tc><w:tcPr><w:vAlign w:val="bottom"/><w:tcMar><w:top w:w="0" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:t>Cell content</w:t></w:r></w:p></w:tc></w:tr></w:tbl>';
  zip.file('word/document.xml', xml.replace(/<w:body>[\s\S]*?(<w:sectPr[\s\S]*?<\/w:sectPr>)<\/w:body>/, `<w:body>${table}$1</w:body>`));
  const source = await zip.generateAsync({ type: 'nodebuffer' });
  await writeFile(path.join(audit, 'cell-source.docx'), source);
  await page.goto('/#/components/office-studio');
  const importFile = (buffer: Buffer, name: string) => page.getByLabel('导入文档文件', { exact: true }).setInputFiles({ name, mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', buffer });
  await importFile(source, 'Cell.docx');
  const body = page.getByRole('textbox', { name: 'Word 文档正文', exact: true });
  const cell = body.locator('td').first();
  const check = async () => {
    const metrics = await cell.evaluate(element => {
      const wrapper = element.querySelector<HTMLElement>('[data-word-cell-content]')!;
      return { height: element.getBoundingClientRect().height, top: getComputedStyle(wrapper).paddingTop, bottom: getComputedStyle(wrapper).paddingBottom };
    });
    expect(metrics.height).toBeGreaterThanOrEqual(31); expect(metrics.height).toBeLessThanOrEqual(33);
    expect(metrics.top).toBe('0px'); expect(parseFloat(metrics.bottom)).toBeCloseTo(20 / 3, 1);
  };
  await check();
  await cell.locator('p').click();
  await page.getByRole('tab', { name: '插入', exact: true }).click();
  await page.getByRole('button', { name: '单元格对齐与边距', exact: true }).click();
  await page.getByRole('button', { name: '下右对齐', exact: true }).click();
  await page.getByRole('textbox', { name: '单元格left内边距', exact: true }).fill('5.25');
  await page.getByRole('button', { name: '应用单元格属性', exact: true }).click();
  await check();
  for (let round = 1; round <= 2; round++) {
    const pending = page.waitForEvent('download');
    await page.getByRole('button', { name: '导出文件', exact: true }).click();
    const bytes = await readFile((await (await pending).path())!);
    await writeFile(path.join(audit, `cell-round-${round}.docx`), bytes);
    await importFile(bytes, `Cell-round-${round}.docx`);
    await check();
    await expect(cell).toHaveCSS('padding-left', '7px');
  }
  await page.screenshot({ path: path.join(audit, 'cell-fixed-light.png'), fullPage: true });
});
